package treinamento;

public class Metodos {


   public void senha ( String senha ) {

        System.out.println("");


   }
}
